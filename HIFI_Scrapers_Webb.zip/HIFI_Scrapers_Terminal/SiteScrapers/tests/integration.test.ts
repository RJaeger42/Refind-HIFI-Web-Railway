import { test, expect, chromium } from '@playwright/test';
import {
  AkkelisAudioPlaywright,
  HifiPulsPlaywright,
  HifiSharkPlaywright,
  TraderaPlaywright,
  ReferenceAudioPlaywright,
  ListingResult,
} from '../index';

/**
 * Integration tests - actually test against real websites
 * These tests verify that scrapers can:
 * 1. Connect to websites
 * 2. Navigate pages
 * 3. Extract data
 * 4. Parse results correctly
 *
 * Run with: npx playwright test integration.test.ts
 * Note: These tests hit real websites, so they may be slower and fail
 * if sites change or are temporarily unavailable
 */

test.describe('Real Website Integration Tests', () => {
  let browser: any;

  test.beforeAll(async () => {
    browser = await chromium.launch({
      headless: true,
    });
  });

  test.afterAll(async () => {
    await browser.close();
  });

  test.describe('AkkelisAudio Scraper', () => {
    test('can connect and return results', async () => {
      const scraper = new AkkelisAudioPlaywright({
        timeout: 30000,
      });

      (scraper as any)['initializeBrowser'](browser);

      try {
        const results = await scraper.search('amplifier');

        // Should be array
        expect(Array.isArray(results)).toBe(true);

        // If results exist, check structure
        if (results.length > 0) {
          const listing = results[0];
          expect(listing.title).toBeDefined();
          expect(typeof listing.title).toBe('string');
          expect(listing.url).toBeDefined();
          expect(listing.url).toMatch(/^https?:\/\//);
        }
      } finally {
        await scraper.close();
      }
    }, { timeout: 60000 });

    test('returns empty array for invalid query', async () => {
      const scraper = new AkkelisAudioPlaywright();
      (scraper as any)['initializeBrowser'](browser);

      try {
        const results = await scraper.search('xyzabc123invalid');
        expect(Array.isArray(results)).toBe(true);
      } finally {
        await scraper.close();
      }
    }, { timeout: 30000 });

    test('supports price filtering', async () => {
      const scraper = new AkkelisAudioPlaywright();
      (scraper as any)['initializeBrowser'](browser);

      try {
        const results = await scraper.search('amplifier', 1000, 5000);
        expect(Array.isArray(results)).toBe(true);

        // All results should be within price range
        for (const result of results) {
          if (result.price !== undefined) {
            expect(result.price).toBeGreaterThanOrEqual(1000);
            expect(result.price).toBeLessThanOrEqual(5000);
          }
        }
      } finally {
        await scraper.close();
      }
    }, { timeout: 30000 });
  });

  test.describe('HiFi Puls Scraper', () => {
    test('can connect and return results', async () => {
      const scraper = new HifiPulsPlaywright({
        timeout: 30000,
        requestDelay: 1000,
      });

      (scraper as any)['initializeBrowser'](browser);

      try {
        const results = await scraper.search('amplifier');

        expect(Array.isArray(results)).toBe(true);

        if (results.length > 0) {
          const listing = results[0];
          expect(listing.title).toBeDefined();
          expect(listing.url).toMatch(/^https?:\/\//);
        }
      } finally {
        await scraper.close();
      }
    }, { timeout: 60000 });

    test('handles pagination correctly', async () => {
      const scraper = new HifiPulsPlaywright({
        maxPages: 2,
        requestDelay: 1500,
      });

      (scraper as any)['initializeBrowser'](browser);

      try {
        const results = await scraper.search('speaker');

        // Should return results if site has them
        expect(Array.isArray(results)).toBe(true);
      } finally {
        await scraper.close();
      }
    }, { timeout: 120000 });
  });

  test.describe('HiFi Shark Scraper', () => {
    test('can extract search data from page context', async () => {
      const scraper = new HifiSharkPlaywright({
        timeout: 45000,
      });

      (scraper as any)['initializeBrowser'](browser);

      try {
        // HiFi Shark filters by country
        const results = await scraper.search('amplifier');

        expect(Array.isArray(results)).toBe(true);

        if (results.length > 0) {
          const listing = results[0];
          expect(listing.title).toBeDefined();
          expect(listing.url).toMatch(/^https?:\/\//);
          // HiFi Shark should have location (country)
          if (listing.location) {
            expect(typeof listing.location).toBe('string');
          }
        }
      } finally {
        await scraper.close();
      }
    }, { timeout: 60000 });
  });

  test.describe('Tradera Scraper', () => {
    test('can extract auction listings', async () => {
      const scraper = new TraderaPlaywright({
        timeout: 30000,
        maxPages: 1,
      });

      (scraper as any)['initializeBrowser'](browser);

      try {
        const results = await scraper.search('amplifier');

        expect(Array.isArray(results)).toBe(true);

        if (results.length > 0) {
          const listing = results[0];
          expect(listing.title).toBeDefined();
          expect(listing.url).toMatch(/^https?:\/\//);
          expect(listing.price === undefined || typeof listing.price === 'number').toBe(true);
        }
      } finally {
        await scraper.close();
      }
    }, { timeout: 60000 });
  });

  test.describe('ReferenceAudio Scraper (Ashop)', () => {
    test('can extract Ashop product data', async () => {
      const scraper = new ReferenceAudioPlaywright({
        timeout: 30000,
      });

      (scraper as any)['initializeBrowser'](browser);

      try {
        const results = await scraper.search('amplifier');

        expect(Array.isArray(results)).toBe(true);

        if (results.length > 0) {
          const listing = results[0];
          expect(listing.title).toBeDefined();
          expect(listing.url).toMatch(/^https?:\/\//);
        }
      } finally {
        await scraper.close();
      }
    }, { timeout: 60000 });
  });
});

test.describe('Listing Result Structure Validation', () => {
  test('ListingResult has all required properties', () => {
    const listing: ListingResult = {
      title: 'Test Product',
      url: 'https://example.com/product',
      description: 'Test description',
      price: 1234.56,
      imageUrl: 'https://example.com/image.jpg',
      location: 'Sweden',
      postedDate: '2024-01-01',
      rawData: { source: 'test' },
    };

    expect(listing.title).toBeDefined();
    expect(listing.url).toBeDefined();
    expect(listing.price).toBeDefined();
  });

  test('ListingResult optional properties work', () => {
    const listing: ListingResult = {
      title: 'Minimal Product',
      url: 'https://example.com/product',
    };

    expect(listing.title).toBe('Minimal Product');
    expect(listing.description).toBeUndefined();
    expect(listing.price).toBeUndefined();
  });
});

test.describe('Error Handling', () => {
  let browser: any;

  test.beforeAll(async () => {
    browser = await chromium.launch();
  });

  test.afterAll(async () => {
    await browser.close();
  });

  test('scraper handles empty query gracefully', async () => {
    const scraper = new AkkelisAudioPlaywright();
    (scraper as any)['initializeBrowser'](browser);

    try {
      const result = await scraper.search('');
      expect(Array.isArray(result)).toBe(true);
      expect(result.length).toBe(0);
    } finally {
      await scraper.close();
    }
  });

  test('scraper handles null/undefined safely', async () => {
    const scraper = new HifiPulsPlaywright();
    (scraper as any)['initializeBrowser'](browser);

    try {
      // Should handle falsy queries
      const result = await scraper.search('');
      expect(Array.isArray(result)).toBe(true);
    } finally {
      await scraper.close();
    }
  });
});
