import { Page } from '@playwright/test';
import { BaseSiteScraper } from '../base.js';
import { ListingResult, SearchParams } from '../types.js';

export class BlocketScraper extends BaseSiteScraper {
  constructor() {
    super({
      name: 'Blocket',
      baseUrl: 'https://www.blocket.se',
      slug: 'blocket',
    });
  }

  async search(page: Page, params: SearchParams): Promise<ListingResult[]> {
    throw new Error('BlocketScraper.search has not been ported to TypeScript yet.');
  }
}

/* Python reference:
  async def search(self, query: str, min_price: Optional[float] = None, 
                      max_price: Optional[float] = None, **kwargs) -> List[ListingResult]:
          """Search Blocket for listings"""
          results = []

          # Build search URL
          search_url = f"{self.base_url}/annonser/hela_sverige"
          params = {
              'q': query,
          }

          if min_price:
              params['price_min'] = int(min_price)
          if max_price:
              params['price_max'] = int(max_price)

          param_string = '&'.join([f"{k}={quote_plus(str(v))}" for k, v in params.items()])
          full_url = f"{search_url}?{param_string}"

          # Blocket uses JavaScript to load listings, so we need Playwright
          soup = None

          try:
              browser = await self._get_browser()
              page = await browser.new_page()

              await page.goto(full_url, wait_until='networkidle', timeout=30000)
              await page.wait_for_timeout(5000)  # Wait for listings to load

              # Wait for listing elements to appear
              try:
                  await page.wait_for_selector('a[href*="/annonser/hela_sverige/"]', timeout=10000)
              except Exception:
                  pass

              # Scroll multiple times to trigger lazy loading
              for i in range(3):
                  await page.evaluate("window.scrollTo(0, document.body.scrollHeight)")
                  await page.wait_for_timeout(2000)

              # Get rendered HTML and parse with BeautifulSoup
              content = await page.content()
              await page.close()

              soup = BeautifulSoup(content, 'html.parser')
          except Exception:
              # Fallback to regular fetch
              soup = self._fetch_page(full_url)
              if not soup:
                  return results

              # Use the specific CSS classes from the working scraper
              # Based on the working scraper: article with class "hidZFy"
              # Strategy 1: Look for article elements with class "hidZFy" (old class name)
              listings = soup.find_all('article', class_='hidZFy')

              # Strategy 2: Look for articles with new styled-components classes
              if not listings:
                  listings = soup.find_all('article', class_=lambda x: x and ('styled__Article' in str(x) or 'hCtEgx' in str(x)))

              # Strategy 3: Look for any article that contains prices and listing links
              if not listings:
                  all_articles = soup.find_all('article')
                  for article in all_articles:
                      # Check if article contains a price
                      price_text = article.find(string=re.compile(r'\d+.*kr', re.I))
                      if not price_text:
                          continue

                      # Check if article contains a link (could be in various formats)
                      links = article.find_all('a', href=True)
                      has_listing_link = False
                      for link in links:
                          href = link.get('href', '')
                          # Look for links that go to actual listings (not category pages)
                          if re.search(r'/annonser/(?:hela_sverige|[\w]+)/[^/?]+/[^/?]+', href):
                              if '?' in href:
                                  url_parts = [p for p in href.split('?')[0].split('/') if p]
                                  if len(url_parts) > 4:
                                      has_listing_link = True
                                      break
                              else:
                                  url_parts = [p for p in href.split('/') if p]
                                  if len(url_parts) >= 4:
                                      has_listing_link = True
                                      break

                      if has_listing_link and article not in listings:
                          listings.append(article)

              # Strategy 4: Fallback - look for any article with listing-like classes
              if not listings:
                  listings = soup.find_all('article', class_=lambda x: x and ('item' in str(x).lower() or 'ad' in str(x).lower() or 'listing' in str(x).lower()))

              for listing in listings:
                  try:
                      listing_data = self._parse_listing(listing)
                      if listing_data:
                          results.append(listing_data)
                  except Exception:
                      continue

          return results
*/
